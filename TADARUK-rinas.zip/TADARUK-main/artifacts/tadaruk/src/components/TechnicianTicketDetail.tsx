import { useState, useEffect, useRef, type ChangeEvent } from 'react';
import { Link } from 'wouter';
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Building2,
  Camera,
  Check,
  CheckCircle2,
  CircleAlert,
  ClipboardList,
  Clock3,
  FileText,
  LoaderCircle,
  MapPin,
  MapPinned,
  Maximize2,
  Lightbulb,
  Sparkles,
  Mic,
  RotateCcw,
  Square,
  UserRound,
  Wrench,
  X,
} from 'lucide-react';
import {
  getGetAiStatusQueryKey,
  getListSimilarSolutionsQueryKey,
  useGetAiStatus,
  useListSimilarSolutions,
  useSuggestTicketFix,
  type DemoUser,
  type SimilarSolution,
  type Ticket,
} from '@workspace/api-client-react';

type Lang = 'ar' | 'en';

const tr = (lang: Lang, ar: string, en: string) => (lang === 'ar' ? ar : en);

function priorityBadgeClass(priority: string) {
  if (priority === 'urgent') return 'priority-urgent';
  if (priority === 'high') return 'priority-high';
  if (priority === 'low') return 'priority-low';
  return 'priority-medium';
}

function priorityLabel(priority: string, lang: Lang) {
  const map: Record<string, [string, string]> = {
    urgent: ['طارئة', 'Urgent'],
    high: ['عالية', 'High'],
    medium: ['متوسطة', 'Medium'],
    low: ['منخفضة', 'Low'],
  };
  const item = map[priority] || ['متوسطة', 'Medium'];
  return lang === 'ar' ? item[0] : item[1];
}

function statusBadgeClass(status: string) {
  return `status-pill status-${status}`;
}

function statusLabel(status: string, lang: Lang) {
  const map: Record<string, [string, string]> = {
    new: ['جديد', 'New'],
    review: ['قيد المراجعة', 'In review'],
    in_progress: ['قيد التنفيذ', 'In progress'],
    awaiting_confirmation: ['بانتظار التأكيد', 'Awaiting confirmation'],
    closed: ['مغلق', 'Closed'],
    cancelled: ['ملغي', 'Cancelled'],
  };
  const item = map[status] || [status, status];
  return lang === 'ar' ? item[0] : item[1];
}

function classificationText(value: string | undefined, lang: Lang) {
  const map: Record<string, [string, string]> = {
    plumbing: ['سباكة ومياه', 'Plumbing & Water'],
    electrical: ['كهرباء وإنارة', 'Electrical & Lighting'],
    cooling: ['تكييف وتبريد', 'HVAC & Cooling'],
    equipment: ['معدات وآلات', 'Equipment & Machinery'],
    civil: ['أعمال مدنية وتشطيبات', 'Civil & Facilities'],
    safety: ['سلامة وأمان', 'Safety & Security'],
  };
  if (!value) return tr(lang, 'صيانة عامة', 'General maintenance');
  const found = map[value.toLowerCase()];
  return found ? (lang === 'ar' ? found[0] : found[1]) : value;
}

function dateText(value: string | undefined, lang: Lang) {
  if (!value) return '';
  try {
    const d = new Date(value);
    return d.toLocaleDateString(lang === 'ar' ? 'ar-SA' : 'en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return value;
  }
}

function branchMapUrl(
  lat: number | null | undefined,
  lng: number | null | undefined,
  address: string | null | undefined,
  city: string | null | undefined,
  customUrl: string | null | undefined
) {
  if (customUrl) return customUrl;
  if (lat && lng) return `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
  const query = [address, city].filter(Boolean).join(', ');
  if (query) return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
  return undefined;
}

/* Minimalist Voice Recorder for Technicians */
function TechVoiceRecorder({
  lang,
  onTranscript,
}: {
  lang: Lang;
  onTranscript: (text: string) => void;
}) {
  const [recording, setRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [bars, setBars] = useState<number[]>(() => Array(16).fill(4));
  const [error, setError] = useState('');
  const recognitionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<number | null>(null);
  const animFrameRef = useRef<number | null>(null);

  const cleanup = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
      recognitionRef.current = null;
    }
    setRecording(false);
    setBars(Array(16).fill(4));
  };

  useEffect(() => {
    return () => cleanup();
  }, []);

  const startRecording = async () => {
    setError('');
    setSeconds(0);
    const speechWindow = window as any;
    const Speech = speechWindow.SpeechRecognition || speechWindow.webkitSpeechRecognition;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      // Audio frequency visualizer
      const AudioCtx = window.AudioContext || speechWindow.webkitAudioContext;
      if (AudioCtx) {
        const audioCtx = new AudioCtx();
        const source = audioCtx.createMediaStreamSource(stream);
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 64;
        source.connect(analyser);
        const buffer = new Uint8Array(analyser.frequencyBinCount);

        const updateBars = () => {
          analyser.getByteFrequencyData(buffer);
          setBars(Array.from({ length: 16 }, (_, i) => Math.max(4, Math.min(26, (buffer[i] || 0) / 8))));
          animFrameRef.current = requestAnimationFrame(updateBars);
        };
        updateBars();
      }

      // Speech recognition if supported
      if (Speech) {
        const recognition = new Speech();
        recognition.lang = lang === 'ar' ? 'ar-SA' : 'en-US';
        recognition.continuous = true;
        recognition.interimResults = false;

        recognition.onresult = (event: any) => {
          let fullText = '';
          for (let i = 0; i < event.results.length; i++) {
            fullText += event.results[i][0].transcript + ' ';
          }
          if (fullText.trim()) {
            onTranscript(fullText.trim());
          }
        };

        recognition.onerror = (e: any) => {
          if (e.error !== 'no-speech') {
            setError(tr(lang, 'تعذر التعرّف على الصوت. يمكنك كتابة الحل بدلاً من ذلك.', 'Speech recognition error. You can type instead.'));
          }
        };

        recognition.start();
        recognitionRef.current = recognition;
      }

      timerRef.current = window.setInterval(() => {
        setSeconds(s => s + 1);
      }, 1000);

      setRecording(true);
    } catch {
      setError(tr(lang, 'يرجى السماح بالوصول إلى الميكروفون أو كتابة الحل في خانة النص.', 'Microphone access denied. Please allow permission or type the solution.'));
    }
  };

  const stopRecording = () => {
    cleanup();
  };

  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-3">
        {!recording ? (
          <button
            type="button"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#1f3363] text-white text-xs font-bold hover:bg-[#2b457e] transition-all"
            onClick={startRecording}
          >
            <Mic size={15} />
            <span>{tr(lang, 'بدء التسجيل الصوتي', 'Start recording')}</span>
          </button>
        ) : (
          <button
            type="button"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 transition-all animate-pulse"
            onClick={stopRecording}
          >
            <Square size={13} fill="currentColor" />
            <span>{tr(lang, 'إيقاف وحفظ التسجيل', 'Stop & save')} ({formatSeconds(seconds)})</span>
          </button>
        )}

        {recording && (
          <div className="flex items-center gap-1 h-6 px-2 bg-slate-100 dark:bg-slate-800 rounded-md">
            {bars.map((bar, i) => (
              <span
                key={i}
                className="w-1 bg-[#307190] dark:bg-[#56f4ef] rounded-full transition-all duration-75"
                style={{ height: `${bar}px` }}
              />
            ))}
          </div>
        )}
      </div>

      {error && (
        <p className="text-xs text-rose-500 m-0">{error}</p>
      )}
    </div>
  );
}

/**
 * Fixes from earlier, confirmed tickets that look like this one. The technician
 * can copy one into the repair note as a starting point.
 */
function SimilarSolutionsPanel({
  ticket,
  lang,
  onUse,
}: {
  ticket: Ticket;
  lang: Lang;
  onUse?: (solution: SimilarSolution) => void;
}) {
  const { data, isLoading } = useListSimilarSolutions(ticket.id, {
    query: { queryKey: getListSimilarSolutionsQueryKey(ticket.id), staleTime: 30_000 },
  });
  const solutions = Array.isArray(data) ? data : [];
  if (isLoading) {
    return (
      <section className="tech-similar-card" aria-busy="true">
        <div className="tech-similar-head">
          <Lightbulb size={16} />
          <h3>{tr(lang, 'نبحث عن مشاكل مشابهة انحلت قبل...', 'Looking for similar solved problems...')}</h3>
        </div>
      </section>
    );
  }
  if (!solutions.length) return null;
  return (
    <section className="tech-similar-card" data-testid="panel-similar-solutions">
      <div className="tech-similar-head">
        <Lightbulb size={16} />
        <div>
          <h3>{tr(lang, 'حلول مقترحة من مشاكل مشابهة', 'Suggested fixes from similar problems')}</h3>
          <p>
            {tr(
              lang,
              'هذه حلول سجّلها الفنيون لبلاغات شبيهة وأكد المبلّغ نجاحها.',
              'Fixes technicians documented on similar tickets, confirmed by the reporter.',
            )}
          </p>
        </div>
      </div>
      <ul className="tech-similar-list">
        {solutions.map(solution => (
          <li key={solution.ticketId} className="tech-similar-item" data-testid={`similar-${solution.ticketNumber}`}>
            <div className="tech-similar-meta">
              <b>{solution.title}</b>
              <span className="tech-similar-score" title={tr(lang, 'نسبة التشابه', 'Similarity')}>
                {tr(lang, `تشابه ${solution.score}٪`, `${solution.score}% match`)}
              </span>
            </div>
            {solution.cause && (
              <p className="tech-similar-line">
                <span>{tr(lang, 'السبب:', 'Cause:')}</span> {solution.cause}
              </p>
            )}
            <p className="tech-similar-line">
              <span>{tr(lang, 'الحل:', 'Fix:')}</span> {solution.resolution}
            </p>
            <div className="tech-similar-foot">
              <small>
                {solution.ticketNumber}
                {solution.technicianName ? ` · ${solution.technicianName}` : ''}
                {solution.branchName ? ` · ${solution.branchName}` : ''}
              </small>
              {onUse && (
                <button
                  type="button"
                  className="tech-similar-use"
                  onClick={() => onUse(solution)}
                  data-testid={`button-use-solution-${solution.ticketNumber}`}
                >
                  <Check size={13} />
                  {tr(lang, 'استخدم هذا الحل', 'Use this fix')}
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}

/**
 * Claude reads the ticket plus the closest confirmed fixes and proposes steps.
 * Only shown when the server has AI configured.
 */
function AiFixSuggestionCard({
  ticket,
  lang,
  onUse,
}: {
  ticket: Ticket;
  lang: Lang;
  onUse?: (text: string) => void;
}) {
  const status = useGetAiStatus({ query: { queryKey: getGetAiStatusQueryKey(), staleTime: 5 * 60_000 } });
  const suggest = useSuggestTicketFix();
  if (status.data?.enabled !== true) return null;
  const result = suggest.data;
  return (
    <section className="tech-similar-card tech-ai-card" data-testid="panel-ai-suggestion">
      <div className="tech-similar-head">
        <Sparkles size={16} />
        <div>
          <h3>{tr(lang, 'اقتراح الذكاء الاصطناعي', 'AI repair suggestion')}</h3>
          <p>
            {tr(
              lang,
              'يقرأ البلاغ والحلول المؤكدة لمشاكل مشابهة ويقترح خطوات. راجعها بخبرتك قبل التنفيذ.',
              'Reads the ticket and confirmed fixes for similar problems, then proposes steps. Use your judgment before acting.',
            )}
          </p>
        </div>
      </div>

      {!result && (
        <button
          type="button"
          className="tech-similar-use tech-ai-ask"
          disabled={suggest.isPending}
          onClick={() => suggest.mutate({ ticketId: ticket.id })}
          data-testid="button-ai-suggest"
        >
          {suggest.isPending ? <LoaderCircle size={13} className="animate-spin" /> : <Sparkles size={13} />}
          {suggest.isPending
            ? tr(lang, 'جارٍ التفكير...', 'Thinking...')
            : tr(lang, 'اقترح لي طريقة الحل', 'Suggest how to fix it')}
        </button>
      )}
      {suggest.isError && (
        <p className="tech-similar-line">{tr(lang, 'تعذر الحصول على اقتراح الآن.', 'Could not get a suggestion right now.')}</p>
      )}
      {result && !result.available && (
        <p className="tech-similar-line">{tr(lang, 'الاقتراح غير متاح حالياً.', 'Suggestion is not available right now.')}</p>
      )}
      {result?.available && (
        <div className="tech-ai-result" data-testid="ai-suggestion-result">
          <p className="tech-similar-line"><b>{result.summary}</b></p>
          {result.likelyCause && (
            <p className="tech-similar-line"><span>{tr(lang, 'السبب المحتمل:', 'Likely cause:')}</span> {result.likelyCause}</p>
          )}
          <ol className="tech-ai-steps">
            {result.steps.map(step => <li key={step}>{step}</li>)}
          </ol>
          {result.safetyNote && (
            <p className="tech-ai-safety"><CircleAlert size={14} /> {result.safetyNote}</p>
          )}
          <div className="tech-similar-foot">
            <small>
              {result.basedOn.length
                ? tr(lang, `مبني على: ${result.basedOn.join('، ')}`, `Based on: ${result.basedOn.join(', ')}`)
                : tr(lang, 'لا توجد حلول سابقة مطابقة؛ خطوات فحص عامة.', 'No matching past fixes; general inspection steps.')}
            </small>
            {onUse && (
              <button
                type="button"
                className="tech-similar-use"
                onClick={() => onUse(result.steps.join('، '))}
                data-testid="button-use-ai-suggestion"
              >
                <Check size={13} />
                {tr(lang, 'استخدمه كبداية للحل', 'Use as a starting note')}
              </button>
            )}
          </div>
        </div>
      )}
    </section>
  );
}

export interface TechnicianTicketDetailProps {
  ticket: Ticket;
  lang: Lang;
  user: DemoUser;
  act: (action: 'start' | 'complete' | 'confirm' | 'reject' | 'reassign', extra?: Record<string, string>) => void;
  action: { isPending: boolean };
  actionFeedback?: string;
  localPhoto?: string;
  reduced?: boolean;
}

export function TechnicianTicketDetail({
  ticket,
  lang,
  user,
  act,
  action,
  actionFeedback,
  localPhoto,
}: TechnicianTicketDetailProps) {
  // Input method: 'text' or 'voice' (allow ONE input method)
  const [inputMode, setInputMode] = useState<'text' | 'voice'>('text');
  const [solutionText, setSolutionText] = useState(ticket.resolution || ticket.repairNotes || '');
  const [repairPhoto, setRepairPhoto] = useState<string>(() => {
    return localStorage.getItem(`tadaruk-repair-photo:${ticket.id}`) || '';
  });
  const [expandedPhoto, setExpandedPhoto] = useState<string | null>(null);

  // Sync solution text if ticket changes from backend
  useEffect(() => {
    if (ticket.resolution || ticket.repairNotes) {
      setSolutionText(ticket.resolution || ticket.repairNotes || '');
    }
    const saved = localStorage.getItem(`tadaruk-repair-photo:${ticket.id}`);
    if (saved) setRepairPhoto(saved);
  }, [ticket.id, ticket.resolution, ticket.repairNotes]);

  // Stage mapping (1: Received, 2: In Progress, 3: Awaiting Confirmation, 4: Closed)
  const currentStage =
    ticket.status === 'closed' ? 4
    : ticket.status === 'awaiting_confirmation' ? 3
    : ticket.status === 'in_progress' ? 2
    : 1;

  // Permissions: Is this ticket assigned to current technician?
  const isAssignedToMe = !ticket.technicianId || ticket.technicianId === user.id;

  // Reported issue photo
  const reportedPhotoUrl = ticket.imageUrl || localPhoto || null;

  // Handle repair photo upload
  const handleRepairPhotoChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const dataUrl = ev.target?.result as string;
      if (dataUrl) {
        setRepairPhoto(dataUrl);
        localStorage.setItem(`tadaruk-repair-photo:${ticket.id}`, dataUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  const mapLink = branchMapUrl(
    ticket.branchLatitude,
    ticket.branchLongitude,
    ticket.branchAddress,
    ticket.branchCity,
    ticket.branchGoogleMapsUrl
  );

  return (
    <div className="tech-detail-page">
      {/* 1. Top Navigation & Context */}
      <div className="tech-detail-back">
        <Link href="/workspace/tickets" className="tech-back-link">
          {lang === 'ar' ? <ArrowRight size={15} /> : <ArrowLeft size={15} />}
          <span>{tr(lang, 'العودة إلى قائمة المهام', 'Back to tasks')}</span>
        </Link>

        <div className="tech-header-meta">
          <span className="tech-ticket-id-pill">{ticket.number}</span>
          {mapLink && (
            <a
              className="tech-map-pill"
              href={mapLink}
              target="_blank"
              rel="noreferrer"
              title={tr(lang, 'موقع الفرع في خرائط Google', 'Open location on Google Maps')}
            >
              <MapPinned size={14} />
              <span>{tr(lang, 'موقع الفرع في الخرائط', 'Branch on Maps')}</span>
              <ArrowUpRight size={13} />
            </a>
          )}
        </div>
      </div>

      {/* Permission alert if assigned to another technician */}
      {!isAssignedToMe && (
        <div className="tech-notice-card" role="alert">
          <CircleAlert size={18} className="flex-shrink-0" />
          <div>
            <b>{tr(lang, 'هذا البلاغ مسند إلى فني آخر', 'Assigned to another technician')}</b>
            <p>
              {tr(
                lang,
                `المسؤول عن معالجة هذا العطل هو ${ticket.technicianName}. يمكنك الاطلاع على التفاصيل فقط.`,
                `This ticket is assigned to ${ticket.technicianName}. You can view the information in read-only mode.`
              )}
            </p>
          </div>
        </div>
      )}

      {/* 2. Priority 1: Hero Task Information Card */}
      <header className="tech-hero-card">
        <div className="tech-hero-badges">
          <span className={statusBadgeClass(ticket.status)}>
            {statusLabel(ticket.status, lang)}
          </span>
          <span className={`priority-badge ${priorityBadgeClass(ticket.priority)}`}>
            {priorityLabel(ticket.priority, lang)}
          </span>
          <span className="tech-spec-tag">
            <Wrench size={13} />
            {classificationText(ticket.specialization || ticket.category, lang)}
          </span>
        </div>

        <h1 className="tech-hero-title">{ticket.title}</h1>

        <div className="tech-meta-strip">
          <span className="tech-meta-item">
            <Building2 size={15} />
            <b>{ticket.branchName}</b>
          </span>
          <span className="tech-meta-item">
            <MapPin size={15} />
            <span>{ticket.location}</span>
          </span>
          <span className="tech-meta-item">
            <UserRound size={15} />
            <span>{tr(lang, 'المبلّغ:', 'Reporter:')} {ticket.reporterName}</span>
          </span>
          <span className="tech-meta-item">
            <Clock3 size={15} />
            <time>{dateText(ticket.createdAt, lang)}</time>
          </span>
        </div>
      </header>

      {/* Suggested fixes from the knowledge base while the work is still open */}
      {['new', 'review', 'in_progress'].includes(ticket.status) && (
        <AiFixSuggestionCard
          ticket={ticket}
          lang={lang}
          onUse={ticket.status === 'in_progress' && isAssignedToMe ? text => {
            setInputMode('text');
            setSolutionText(text);
          } : undefined}
        />
      )}
      {['new', 'review', 'in_progress'].includes(ticket.status) && (
        <SimilarSolutionsPanel
          ticket={ticket}
          lang={lang}
          onUse={ticket.status === 'in_progress' && isAssignedToMe ? solution => {
            setInputMode('text');
            setSolutionText(solution.resolution);
          } : undefined}
        />
      )}

      {/* 3. Priority 2: Clear Section to Update Ticket Status (Action Hub) */}
      <section className="tech-action-hub" aria-busy={action.isPending}>
        {/* Visual 4-Stage Pipeline */}
        <div className="tech-stages-bar" aria-label={tr(lang, 'مراحل متابعة العطل', 'Repair stages')}>
          {[
            { step: 1, ar: 'استلام الطلب', en: 'Received' },
            { step: 2, ar: 'قيد التنفيذ', en: 'In progress' },
            { step: 3, ar: 'بانتظار التأكيد', en: 'Confirmation' },
            { step: 4, ar: 'تم الإغلاق', en: 'Closed' },
          ].map(st => {
            const isPast = currentStage > st.step;
            const isCurrent = currentStage === st.step;
            return (
              <div
                key={st.step}
                className={`tech-stage-step ${isPast ? 'is-past' : ''} ${isCurrent ? 'is-current' : ''}`}
              >
                <span className="tech-stage-dot">
                  {isPast ? <Check size={14} strokeWidth={3} /> : st.step}
                </span>
                <span className="tech-stage-label">{tr(lang, st.ar, st.en)}</span>
              </div>
            );
          })}
        </div>

        {/* Action Content Based on Current Status */}
        {ticket.status === 'cancelled' ? (
          <div className="tech-notice-card" role="status">
            <CircleAlert size={18} />
            <div>
              <b>{tr(lang, 'أُلغي هذا البلاغ', 'Report cancelled')}</b>
              <p>{tr(lang, 'تم إلغاء البلاغ قبل بدء أعمال الصيانة.', 'This ticket was cancelled before work started.')}</p>
            </div>
          </div>
        ) : (ticket.status === 'new' || ticket.status === 'review') ? (
          /* STAGE 1: Fast One-Click Start Action (NO forms required!) */
          <div className="tech-action-box highlight-start">
            <div className="tech-action-intro">
              <div className="tech-action-icon-circle">
                <Wrench size={22} />
              </div>
              <div>
                <h3>{tr(lang, 'استلام الطلب وبدء العمل الميداني', 'Acknowledge & Start Work')}</h3>
                <p>
                  {tr(
                    lang,
                    'اضغط لتحديث حالة البلاغ مباشرة إلى "قيد التنفيذ" وإشعار المبلّغ ببدء الإصلاح.',
                    'Click to update ticket status to "In Progress" and notify the reporter immediately.'
                  )}
                </p>
              </div>
            </div>

            <button
              type="button"
              className="tech-primary-action-btn"
              disabled={action.isPending || !isAssignedToMe}
              onClick={() => act('start')}
              data-testid="button-tech-start"
            >
              {action.isPending ? (
                <LoaderCircle size={18} className="animate-spin" />
              ) : (
                <Wrench size={18} />
              )}
              <span>{tr(lang, 'استلمت الطلب — بدء العمل', 'Acknowledge & Start Work')}</span>
            </button>
          </div>
        ) : ticket.status === 'in_progress' ? (
          /* STAGE 2: Simple Repair Documentation Section */
          <div className="tech-action-box highlight-complete">
            <div className="tech-action-intro">
              <div className="tech-action-icon-circle success-tint">
                <CheckCircle2 size={22} />
              </div>
              <div>
                <h3>{tr(lang, 'كيف أصلحت المشكلة؟', 'How did you fix the issue?')}</h3>
                <p>
                  {tr(
                    lang,
                    'اختر طريقة واحدة لشرح الحل (كتابة أو تسجيلاً صوتياً) لإرساله للمبلّغ وتوثيقه في قاعدة المعرفة.',
                    'Choose one method to explain your fix (written or voice) to submit for reporter confirmation.'
                  )}
                </p>
              </div>
            </div>

            {/* Input Method Selector (Choose ONE) */}
            <div className="tech-input-mode-picker" role="tablist">
              <button
                type="button"
                role="tab"
                aria-selected={inputMode === 'text'}
                className={`tech-mode-pill ${inputMode === 'text' ? 'is-active' : ''}`}
                onClick={() => setInputMode('text')}
              >
                <FileText size={15} />
                <span>{tr(lang, 'كتابة الحل (نص)', 'Written solution')}</span>
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={inputMode === 'voice'}
                className={`tech-mode-pill ${inputMode === 'voice' ? 'is-active' : ''}`}
                onClick={() => setInputMode('voice')}
              >
                <Mic size={15} />
                <span>{tr(lang, 'تسجيل صوتي', 'Voice recording')}</span>
              </button>
            </div>

            {/* Input Area */}
            {inputMode === 'text' ? (
              <div className="tech-solution-text-zone">
                <label className="tech-field-label">
                  <span>{tr(lang, 'شرح الإجراء المنفذ (مطلوب)', 'Action taken (required)')}</span>
                  <textarea
                    value={solutionText}
                    onChange={e => setSolutionText(e.target.value)}
                    rows={3}
                    placeholder={tr(
                      lang,
                      'مثال: تم فحص التوصيلات واستبدال الجزء التالف والتأكد من إحكام الغلق وتشغيل الوحدة بنجاح...',
                      'Example: Inspected fittings, replaced damaged section, verified seals, and tested operation...'
                    )}
                    data-testid="input-tech-solution-text"
                    className="tech-solution-textarea"
                  />
                </label>
              </div>
            ) : (
              <div className="tech-solution-voice-zone">
                <div className="tech-voice-card">
                  <span className="tech-voice-hint">
                    {tr(lang, 'سجّل شرحاً موجزاً لما قمت به لحل العطل:', 'Record a brief explanation of how you resolved the issue:')}
                  </span>
                  <TechVoiceRecorder
                    lang={lang}
                    onTranscript={text => {
                      setSolutionText(cur => (cur ? `${cur.trimEnd()} ${text}` : text));
                    }}
                  />
                  {solutionText ? (
                    <div className="tech-voice-result">
                      <span className="tech-voice-result-label">
                        {tr(lang, 'النص المسجل:', 'Transcribed text:')}
                      </span>
                      <p className="tech-voice-result-text">{solutionText}</p>
                      <button
                        type="button"
                        className="tech-voice-clear-btn"
                        onClick={() => setSolutionText('')}
                      >
                        <RotateCcw size={12} />
                        <span>{tr(lang, 'إعادة التسجيل', 'Re-record')}</span>
                      </button>
                    </div>
                  ) : null}
                </div>
              </div>
            )}

            {/* Optional Photo Upload: "صورة بعد الإصلاح" */}
            <div className="tech-after-photo-section">
              <div className="tech-after-photo-head">
                <span className="tech-after-photo-title">
                  <Camera size={14} />
                  {tr(lang, 'صورة بعد الإصلاح (اختياري)', 'Photo after repair (optional)')}
                </span>
                {repairPhoto && (
                  <span className="tech-after-photo-badge">
                    <Check size={12} strokeWidth={2.8} />
                    {tr(lang, 'تم إرفاق صورة', 'Photo attached')}
                  </span>
                )}
              </div>

              {!repairPhoto ? (
                <label className="tech-photo-upload-btn" data-testid="button-upload-repair-photo">
                  <Camera size={16} />
                  <span>{tr(lang, 'التقاط أو رفع صورة للحل', 'Capture or upload repair photo')}</span>
                  <input
                    type="file"
                    accept="image/*"
                    capture="environment"
                    className="sr-only"
                    onChange={handleRepairPhotoChange}
                  />
                </label>
              ) : (
                <div className="tech-repair-photo-preview">
                  <img
                    src={repairPhoto}
                    alt={tr(lang, 'صورة بعد الإصلاح', 'After repair preview')}
                    className="tech-repair-thumb"
                    onClick={() => setExpandedPhoto(repairPhoto)}
                  />
                  <div className="tech-repair-photo-actions">
                    <button
                      type="button"
                      className="tech-photo-action-btn"
                      onClick={() => setExpandedPhoto(repairPhoto)}
                      title={tr(lang, 'تكبير الصورة', 'Expand photo')}
                    >
                      <Maximize2 size={13} />
                    </button>
                    <button
                      type="button"
                      className="tech-photo-action-btn delete"
                      onClick={() => {
                        setRepairPhoto('');
                        localStorage.removeItem(`tadaruk-repair-photo:${ticket.id}`);
                      }}
                      title={tr(lang, 'حذف الصورة', 'Delete photo')}
                    >
                      <X size={13} />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Single Clear Primary Action to Submit for Confirmation */}
            <button
              type="button"
              className="tech-primary-action-btn"
              disabled={!solutionText.trim() || action.isPending || !isAssignedToMe}
              onClick={() => {
                if (repairPhoto) {
                  localStorage.setItem(`tadaruk-repair-photo:${ticket.id}`, repairPhoto);
                }
                act('complete', {
                  note: solutionText.trim(),
                  resolution: solutionText.trim(),
                });
              }}
              data-testid="button-tech-complete"
            >
              {action.isPending ? (
                <LoaderCircle size={18} className="animate-spin" />
              ) : (
                <CheckCircle2 size={18} />
              )}
              <span>{tr(lang, 'إرسال الإصلاح لتأكيد المبلّغ', 'Submit for Reporter Confirmation')}</span>
            </button>
          </div>
        ) : ticket.status === 'awaiting_confirmation' ? (
          /* STAGE 3: Waiting on Reporter Confirmation */
          <div className="tech-action-box">
            <div className="tech-status-card-inner">
              <div className="tech-status-icon-bubble waiting">
                <Clock3 size={24} />
              </div>
              <div className="tech-status-card-copy">
                <h3>{tr(lang, 'تم إرسال الإصلاح — بانتظار مراجعة وتأكيد المبلّغ', 'Repair Submitted — Awaiting Confirmation')}</h3>
                <p>
                  {tr(
                    lang,
                    `تم إشعار المبلّغ (${ticket.reporterName}) لفحص الإصلاح الميداني وتأكيده لإغلاق البلاغ نهائياً.`,
                    `The reporter (${ticket.reporterName}) was notified to inspect the repair and confirm ticket closure.`
                  )}
                </p>
              </div>
            </div>

            {/* Documented Solution Display */}
            <div className="tech-documented-record">
              <span className="tech-record-label">{tr(lang, 'الحل الموثق من طرفك:', 'Documented solution:')}</span>
              <p className="tech-record-text">{ticket.resolution || ticket.repairNotes || solutionText}</p>

              {repairPhoto && (
                <div className="tech-documented-photo">
                  <span className="tech-record-label">{tr(lang, 'صورة بعد الإصلاح:', 'After-repair photo:')}</span>
                  <img
                    src={repairPhoto}
                    alt={tr(lang, 'صورة بعد الإصلاح', 'After repair')}
                    className="tech-documented-img"
                    onClick={() => setExpandedPhoto(repairPhoto)}
                  />
                </div>
              )}
            </div>
          </div>
        ) : (
          /* STAGE 4: Closed / Confirmed */
          <div className="tech-action-box">
            <div className="tech-status-card-inner">
              <div className="tech-status-icon-bubble closed">
                <CheckCircle2 size={24} />
              </div>
              <div className="tech-status-card-copy">
                <h3>{tr(lang, 'تم تأكيد الإصلاح وإغلاق البلاغ بنجاح', 'Repair Confirmed & Ticket Closed')}</h3>
                <p>
                  {tr(
                    lang,
                    'أكد المبلّغ حل المشكلة بنجاح، وتمت إضافة الحل إلى قاعدة المعرفة كمرجع للأعطال المماثلة.',
                    'The reporter confirmed the fix, and this solution was added to the knowledge base.'
                  )}
                </p>
              </div>
            </div>

            <div className="tech-documented-record">
              <span className="tech-record-label">{tr(lang, 'الحل المعتمد في قاعدة المعرفة:', 'Confirmed solution in knowledge base:')}</span>
              <p className="tech-record-text">{ticket.resolution || ticket.repairNotes}</p>
            </div>
          </div>
        )}

        {actionFeedback && (
          <div className="mt-3 text-xs font-bold text-[#1f3363] dark:text-[#56f4ef] flex items-center gap-2">
            <Check size={14} />
            <span>{actionFeedback}</span>
          </div>
        )}
      </section>

      {/* Issue Description & Small Preview of Reported Photo */}
      <section className="tech-info-card">
        <div className="tech-info-header">
          <ClipboardList size={16} className="text-[#307190]" />
          <h3>{tr(lang, 'وصف المشكلة في البلاغ', 'Reported Issue Description')}</h3>
        </div>

        <p className="tech-issue-description">{ticket.description}</p>

        <div className="tech-reported-photo-block">
          <span className="tech-sublabel">{tr(lang, 'صورة العطل المرفقة:', 'Attached issue photo:')}</span>
          {reportedPhotoUrl ? (
            <div className="tech-reported-photo-wrap">
              <button
                type="button"
                className="tech-photo-thumb-trigger"
                onClick={() => setExpandedPhoto(reportedPhotoUrl)}
                aria-label={tr(lang, 'تكبير صورة المشكلة', 'Expand issue photo')}
              >
                <img
                  src={reportedPhotoUrl}
                  alt={tr(lang, 'صورة المشكلة المرفقة', 'Attached issue photo')}
                  className="tech-photo-thumb-img"
                />
                <span className="tech-photo-zoom-overlay">
                  <Maximize2 size={16} />
                  <span>{tr(lang, 'اضغط للتكبير', 'Click to expand')}</span>
                </span>
              </button>
            </div>
          ) : (
            <p className="tech-no-photo-note">
              {tr(lang, 'لم يرفق المبلّغ صورة مع هذا البلاغ.', 'No photo was attached to this report.')}
            </p>
          )}
        </div>
      </section>

      {/* Lightbox / Modal for High-Resolution Photo Expansion */}
      {expandedPhoto && (
        <div
          className="tech-lightbox-scrim"
          onClick={() => setExpandedPhoto(null)}
          role="dialog"
          aria-modal="true"
        >
          <div className="tech-lightbox-content" onClick={e => e.stopPropagation()}>
            <button
              type="button"
              className="tech-lightbox-close"
              onClick={() => setExpandedPhoto(null)}
              aria-label={tr(lang, 'إغلاق', 'Close')}
            >
              <X size={20} />
            </button>
            <img
              src={expandedPhoto}
              alt={tr(lang, 'عرض الصورة بالحجم الكامل', 'Full size view')}
              className="tech-lightbox-img"
            />
          </div>
        </div>
      )}
    </div>
  );
}

