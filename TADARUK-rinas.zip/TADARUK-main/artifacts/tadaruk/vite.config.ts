import path from 'path';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { defineConfig } from 'vite';

import runtimeErrorOverlay from '@replit/vite-plugin-runtime-error-modal';

export default defineConfig(async ({ command }) => {
  const port =
    command === 'build'
      ? undefined
      : (() => {
          const rawPort = process.env.PORT ?? '5173';
          const parsedPort = Number(rawPort);

          if (
            !Number.isInteger(parsedPort) ||
            parsedPort <= 0 ||
            parsedPort > 65535
          ) {
            throw new Error(`Invalid PORT value: "${rawPort}"`);
          }

          return parsedPort;
        })();

  return {
    base: process.env.BASE_PATH ?? '/',
    plugins: [
      react(),
      tailwindcss(),
      runtimeErrorOverlay(),
      ...(process.env.NODE_ENV !== 'production' &&
      process.env.REPL_ID !== undefined
        ? [
            await import('@replit/vite-plugin-cartographer').then((m) =>
              m.cartographer({
                root: path.resolve(import.meta.dirname, '..'),
              }),
            ),
            await import('@replit/vite-plugin-dev-banner').then((m) =>
              m.devBanner(),
            ),
          ]
        : []),
    ],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname, 'src'),
        '@assets': path.resolve(
          import.meta.dirname,
          '..',
          '..',
          'attached_assets',
        ),
      },
      dedupe: ['react', 'react-dom'],
    },
    root: path.resolve(import.meta.dirname),
    build: {
      outDir: path.resolve(import.meta.dirname, 'dist/public'),
      emptyOutDir: true,
    },
    server: {
      ...(port === undefined ? {} : { port }),
      strictPort: true,
      host: '0.0.0.0',
      allowedHosts: true,
      fs: {
        strict: true,
      },
    },
    preview: {
      ...(port === undefined ? {} : { port }),
      host: '0.0.0.0',
      allowedHosts: true,
    },
  };
});
